module ex1 {
}